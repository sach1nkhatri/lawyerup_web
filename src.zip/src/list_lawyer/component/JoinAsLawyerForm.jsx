import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import LawyerScheduleBuilder from './LawyerScheduleBuilder';
import '../css/JoinAsLawyerForm.css';

const JoinAsLawyerForm = ({ onSubmitted }) => {
    const [loading, setLoading] = useState(true);
    const [form, setForm] = useState({
        fullName: '',
        specialization: '',
        email: '',
        phone: '',
        state: '',
        city: '',
        address: '',
        qualification: '',
        profilePhoto: null,
        licenseFile: null,
    });
    const [schedule, setSchedule] = useState({});

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setLoading(false);
            return;
        }
        const fetchUser = async () => {
            try {
                const res = await fetch('http://localhost:5000/api/auth/me', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                if (res.ok) {
                    const user = await res.json();
                    setForm(f => ({
                        ...f,
                        fullName: user.fullName || f.fullName,
                        email: user.email || f.email,
                        phone: user.contactNumber || f.phone,
                    }));
                }
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchUser();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm(prev => ({ ...prev, [name]: value }));
    };

    const handleFileChange = (e, field) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onloadend = () => {
            setForm(prev => ({ ...prev, [field]: reader.result }));
        };
        reader.readAsDataURL(file);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const payload = { ...form, schedule };
            const res = await fetch('http://localhost:5000/api/lawyers', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(payload),
            });
            if (!res.ok) throw new Error('Submission failed');
            toast.success('Application submitted!', { autoClose: 2000 });
            if (onSubmitted) onSubmitted();
        } catch (err) {
            console.error(err);
            toast.error('Failed to submit. Please try again.', { autoClose: 2000 });
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="join-lawyer-container">
                <p>Loading...</p>
            </div>
        );
    }

    return (
        <div className="join-lawyer-container">
            <h2>Join as a Lawyer</h2>
            <p>Your application will be reviewed by an admin.</p>

            <form className="lawyer-form" onSubmit={handleSubmit}>
                <div className="form-grid">
                    <input
                        name="fullName"
                        placeholder="Full Name"
                        value={form.fullName}
                        onChange={handleChange}
                        required
                    />
                    <input
                        name="specialization"
                        placeholder="Specialization"
                        value={form.specialization}
                        onChange={handleChange}
                        required
                    />
                    <input
                        name="email"
                        type="email"
                        placeholder="Email"
                        value={form.email}
                        onChange={handleChange}
                        required
                    />
                    <input
                        name="phone"
                        placeholder="Phone"
                        value={form.phone}
                        onChange={handleChange}
                        required
                    />
                    <input
                        name="state"
                        placeholder="State"
                        value={form.state}
                        onChange={handleChange}
                    />
                    <input
                        name="city"
                        placeholder="City"
                        value={form.city}
                        onChange={handleChange}
                    />
                    <input
                        name="address"
                        placeholder="Street Address"
                        value={form.address}
                        onChange={handleChange}
                    />
                    <input
                        name="qualification"
                        placeholder="Qualification"
                        value={form.qualification}
                        onChange={handleChange}
                    />

                    <div className="file-input">
                        <label>Upload Profile Photo</label>
                        <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleFileChange(e, 'profilePhoto')}
                        />
                    </div>

                    <div className="file-input">
                        <label>Upload License Document</label>
                        <input
                            type="file"
                            accept="application/pdf"
                            onChange={(e) => handleFileChange(e, 'licenseFile')}
                        />
                    </div>
                </div>

                <div className="schedule-builder">
                    <LawyerScheduleBuilder onScheduleChange={setSchedule} />
                </div>

                <button type="submit" className="submit-btn">
                    Join Now
                </button>
            </form>
        </div>
    );
};

export default JoinAsLawyerForm;
