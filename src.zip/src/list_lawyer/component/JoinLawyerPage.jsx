// src/list_lawyer/component/JoinLawyerPage.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import JoinAsLawyerForm from './JoinAsLawyerForm';
import LawyerStatusPanel from './LawyerStatusPanel';
import LawyerFinalListingPanel from './LawyerFinalListingPanel';

const JoinLawyerPage = () => {
    const [view, setView] = useState('loading');
    const [lawyerData, setLawyerData] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setView('form');
            return;
        }

        // fetch the current lawyer application
        fetch('http://localhost:5000/api/lawyers/me', {
            headers: { Authorization: `Bearer ${token}` },
        })
            .then(res => {
                if (!res.ok) throw new Error('no-application');
                return res.json();
            })
            .then(data => {
                setLawyerData(data);
                const status = data.status;
                const nextClicked = localStorage.getItem('lawyerup_nextClicked') === 'true';

                if (['pending', 'hold', 'rejected'].includes(status)) {
                    setView('status');
                } else if (['verified', 'listed'].includes(status)) {
                    setView(nextClicked ? 'control' : 'status');
                } else {
                    setView('status');
                }
            })
            .catch(() => {
                // no existing application
                setView('form');
            });
    }, []);

    const handleNext = () => {
        localStorage.setItem('lawyerup_nextClicked', 'true');
        setView('control');
    };

    const handleReapply = () => {
        localStorage.removeItem('lawyerup_nextClicked');
        setLawyerData(null);
        setView('form');
    };

    if (view === 'loading') {
        return <p style={{ padding: '2rem' }}>Loading your application…</p>;
    }
    if (view === 'form') {
        // pass a callback so that, once the form submits successfully, we
        // immediately move into the status view without navigating away
        return <JoinAsLawyerForm onSubmitted={() => setView('status')} />;
    }
    if (view === 'status') {
        return <LawyerStatusPanel lawyer={lawyerData} onNext={handleNext} />;
    }
    if (view === 'control') {
        return <LawyerFinalListingPanel lawyer={lawyerData} onReapply={handleReapply} />;
    }
    return <p>Something went wrong. Please reload.</p>;
};

export default JoinLawyerPage;
